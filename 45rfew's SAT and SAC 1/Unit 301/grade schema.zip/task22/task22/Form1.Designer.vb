﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.lblGrade = New System.Windows.Forms.Label()
        Me.txtGradeInput = New System.Windows.Forms.TextBox()
        Me.lblMarkOutput = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblGrade
        '
        Me.lblGrade.AutoSize = True
        Me.lblGrade.Location = New System.Drawing.Point(262, 155)
        Me.lblGrade.Name = "lblGrade"
        Me.lblGrade.Size = New System.Drawing.Size(112, 13)
        Me.lblGrade.TabIndex = 0
        Me.lblGrade.Text = "Enter your grade here:"
        '
        'txtGradeInput
        '
        Me.txtGradeInput.AcceptsReturn = True
        Me.txtGradeInput.Location = New System.Drawing.Point(380, 152)
        Me.txtGradeInput.Name = "txtGradeInput"
        Me.txtGradeInput.Size = New System.Drawing.Size(100, 20)
        Me.txtGradeInput.TabIndex = 1
        '
        'lblMarkOutput
        '
        Me.lblMarkOutput.AutoSize = True
        Me.lblMarkOutput.Location = New System.Drawing.Point(262, 213)
        Me.lblMarkOutput.Name = "lblMarkOutput"
        Me.lblMarkOutput.Size = New System.Drawing.Size(0, 13)
        Me.lblMarkOutput.TabIndex = 2
        '
        'form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.lblMarkOutput)
        Me.Controls.Add(Me.txtGradeInput)
        Me.Controls.Add(Me.lblGrade)
        Me.Name = "form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblGrade As Label
    Friend WithEvents txtGradeInput As TextBox
    Friend WithEvents lblMarkOutput As Label
End Class
