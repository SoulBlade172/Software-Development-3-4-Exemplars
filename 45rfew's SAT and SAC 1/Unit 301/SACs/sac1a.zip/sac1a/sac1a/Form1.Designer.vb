﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnswap = New System.Windows.Forms.Button()
        Me.btnclear = New System.Windows.Forms.Button()
        Me.btnexit = New System.Windows.Forms.Button()
        Me.txtday = New System.Windows.Forms.TextBox()
        Me.txtday2 = New System.Windows.Forms.TextBox()
        Me.txtduty = New System.Windows.Forms.TextBox()
        Me.txtduty2 = New System.Windows.Forms.TextBox()
        Me.lblteacher = New System.Windows.Forms.Label()
        Me.lblteacher2 = New System.Windows.Forms.Label()
        Me.lblday = New System.Windows.Forms.Label()
        Me.lblduty = New System.Windows.Forms.Label()
        Me.btnswap2 = New System.Windows.Forms.Button()
        Me.cmbteachers = New System.Windows.Forms.ComboBox()
        Me.cmbteachers2 = New System.Windows.Forms.ComboBox()
        Me.lblheader = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnswap
        '
        Me.btnswap.Location = New System.Drawing.Point(122, 322)
        Me.btnswap.Name = "btnswap"
        Me.btnswap.Size = New System.Drawing.Size(75, 23)
        Me.btnswap.TabIndex = 0
        Me.btnswap.Text = "Swap days"
        Me.btnswap.UseVisualStyleBackColor = True
        '
        'btnclear
        '
        Me.btnclear.Location = New System.Drawing.Point(354, 322)
        Me.btnclear.Name = "btnclear"
        Me.btnclear.Size = New System.Drawing.Size(75, 23)
        Me.btnclear.TabIndex = 1
        Me.btnclear.Text = "Clear"
        Me.btnclear.UseVisualStyleBackColor = True
        '
        'btnexit
        '
        Me.btnexit.Location = New System.Drawing.Point(548, 322)
        Me.btnexit.Name = "btnexit"
        Me.btnexit.Size = New System.Drawing.Size(75, 23)
        Me.btnexit.TabIndex = 2
        Me.btnexit.Text = "Exit"
        Me.btnexit.UseVisualStyleBackColor = True
        '
        'txtday
        '
        Me.txtday.Location = New System.Drawing.Point(496, 114)
        Me.txtday.Name = "txtday"
        Me.txtday.Size = New System.Drawing.Size(100, 20)
        Me.txtday.TabIndex = 5
        '
        'txtday2
        '
        Me.txtday2.Location = New System.Drawing.Point(496, 198)
        Me.txtday2.Name = "txtday2"
        Me.txtday2.Size = New System.Drawing.Size(100, 20)
        Me.txtday2.TabIndex = 6
        '
        'txtduty
        '
        Me.txtduty.Location = New System.Drawing.Point(632, 114)
        Me.txtduty.Name = "txtduty"
        Me.txtduty.Size = New System.Drawing.Size(100, 20)
        Me.txtduty.TabIndex = 7
        '
        'txtduty2
        '
        Me.txtduty2.Location = New System.Drawing.Point(632, 198)
        Me.txtduty2.Name = "txtduty2"
        Me.txtduty2.Size = New System.Drawing.Size(100, 20)
        Me.txtduty2.TabIndex = 8
        '
        'lblteacher
        '
        Me.lblteacher.AutoSize = True
        Me.lblteacher.Location = New System.Drawing.Point(119, 114)
        Me.lblteacher.Name = "lblteacher"
        Me.lblteacher.Size = New System.Drawing.Size(56, 13)
        Me.lblteacher.TabIndex = 9
        Me.lblteacher.Text = "Teacher 1"
        '
        'lblteacher2
        '
        Me.lblteacher2.AutoSize = True
        Me.lblteacher2.Location = New System.Drawing.Point(119, 188)
        Me.lblteacher2.Name = "lblteacher2"
        Me.lblteacher2.Size = New System.Drawing.Size(56, 13)
        Me.lblteacher2.TabIndex = 10
        Me.lblteacher2.Text = "Teacher 2"
        '
        'lblday
        '
        Me.lblday.AutoSize = True
        Me.lblday.Location = New System.Drawing.Point(525, 55)
        Me.lblday.Name = "lblday"
        Me.lblday.Size = New System.Drawing.Size(26, 13)
        Me.lblday.TabIndex = 11
        Me.lblday.Text = "Day"
        '
        'lblduty
        '
        Me.lblduty.AutoSize = True
        Me.lblduty.Location = New System.Drawing.Point(664, 55)
        Me.lblduty.Name = "lblduty"
        Me.lblduty.Size = New System.Drawing.Size(29, 13)
        Me.lblduty.TabIndex = 12
        Me.lblduty.Text = "Duty"
        '
        'btnswap2
        '
        Me.btnswap2.Location = New System.Drawing.Point(122, 366)
        Me.btnswap2.Name = "btnswap2"
        Me.btnswap2.Size = New System.Drawing.Size(75, 23)
        Me.btnswap2.TabIndex = 13
        Me.btnswap2.Text = "Swap duties"
        Me.btnswap2.UseVisualStyleBackColor = True
        '
        'cmbteachers
        '
        Me.cmbteachers.FormattingEnabled = True
        Me.cmbteachers.Location = New System.Drawing.Point(218, 106)
        Me.cmbteachers.Name = "cmbteachers"
        Me.cmbteachers.Size = New System.Drawing.Size(121, 21)
        Me.cmbteachers.TabIndex = 14
        '
        'cmbteachers2
        '
        Me.cmbteachers2.FormattingEnabled = True
        Me.cmbteachers2.Location = New System.Drawing.Point(218, 185)
        Me.cmbteachers2.Name = "cmbteachers2"
        Me.cmbteachers2.Size = New System.Drawing.Size(121, 21)
        Me.cmbteachers2.TabIndex = 15
        '
        'lblheader
        '
        Me.lblheader.AutoSize = True
        Me.lblheader.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblheader.Location = New System.Drawing.Point(74, 35)
        Me.lblheader.Name = "lblheader"
        Me.lblheader.Size = New System.Drawing.Size(225, 33)
        Me.lblheader.TabIndex = 16
        Me.lblheader.Text = "Yard Duty Swap"
        '
        'frm1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.lblheader)
        Me.Controls.Add(Me.cmbteachers2)
        Me.Controls.Add(Me.cmbteachers)
        Me.Controls.Add(Me.btnswap2)
        Me.Controls.Add(Me.lblduty)
        Me.Controls.Add(Me.lblday)
        Me.Controls.Add(Me.lblteacher2)
        Me.Controls.Add(Me.lblteacher)
        Me.Controls.Add(Me.txtduty2)
        Me.Controls.Add(Me.txtduty)
        Me.Controls.Add(Me.txtday2)
        Me.Controls.Add(Me.txtday)
        Me.Controls.Add(Me.btnexit)
        Me.Controls.Add(Me.btnclear)
        Me.Controls.Add(Me.btnswap)
        Me.Name = "frm1"
        Me.Text = "Yard Duty Swap"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnswap As Button
    Friend WithEvents btnclear As Button
    Friend WithEvents btnexit As Button
    Friend WithEvents txtday As TextBox
    Friend WithEvents txtday2 As TextBox
    Friend WithEvents txtduty As TextBox
    Friend WithEvents txtduty2 As TextBox
    Friend WithEvents lblteacher As Label
    Friend WithEvents lblteacher2 As Label
    Friend WithEvents lblday As Label
    Friend WithEvents lblduty As Label
    Friend WithEvents cmbteachers As ComboBox
    Friend WithEvents cmbteachers2 As ComboBox
    Friend WithEvents btnswap2 As Button
    Friend WithEvents lblheader As Label
End Class
