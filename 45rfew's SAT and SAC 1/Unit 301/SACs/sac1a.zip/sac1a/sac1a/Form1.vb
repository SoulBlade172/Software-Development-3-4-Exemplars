﻿'Yard Duty Swapper 
'swaps teacher's yard duty roles
'Date of creation: 3/14/2023
'Author: 45rfew
Public Class frm1
    Dim teachers = {"A. Smith", "P. Cech", "K.Klopp"}, duties = {"Recess, L Block", "Lunch, Oval", "Before School, Grassy Knoll"}, days = {"1", "3", "2"}
    'define arrays as global variables so they can be accessed from anywhere 
    'using seperate arrays to store all the values and allows easy swapping 
    'days is string as there is no calculations done 
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        '   Dim teachers = {"A. Smith", "P. Cech", "K.Klopp"}, duties = {"Recess, L Block", "Lunch, Oval", "Before School, Grassy Knoll"}, days = {1, 3, 2}
        For i = 0 To teachers.Length - 1 'add all elements from teacher array to two comboboxes on load
            cmbteachers.Items.Add(teachers(i))
            cmbteachers2.Items.Add(teachers(i))
        Next
    End Sub
    Private Sub btnswap_Click(sender As Object, e As EventArgs) Handles btnswap.Click
        If cmbteachers.SelectedIndex > -1 And cmbteachers2.SelectedIndex > -1 Then 'checks if there is a selected item in both comboboxes 
            If cmbteachers.SelectedIndex <> cmbteachers2.SelectedIndex Then 'checks if the selected items are not the same 
                swap(days, cmbteachers.SelectedIndex, cmbteachers2.SelectedIndex) 'swap array values based on selected values 
                txtday.Text = days(cmbteachers.SelectedIndex) 'update text
                txtday2.Text = days(cmbteachers2.SelectedIndex)
                MessageBox.Show("swapped")
            Else MessageBox.Show("select two different teachers")
            End If
        Else MessageBox.Show("select teachers")
        End If
    End Sub
    Private Sub cmbteachers_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbteachers.SelectedIndexChanged
        txtday.Text = days(cmbteachers.SelectedIndex) 'updates text when combobox value changes 
        txtduty.Text = duties(cmbteachers.SelectedIndex)
    End Sub
    Private Sub btnclear_Click(sender As Object, e As EventArgs) Handles btnclear.Click
        txtday.Clear() 'clears everything 
        txtday2.Clear()
        txtduty.Clear()
        txtduty2.Clear()
        cmbteachers.Text = ""
        cmbteachers2.Text = ""
    End Sub
    Private Sub btnexit_Click(sender As Object, e As EventArgs) Handles btnexit.Click
        Me.Close()
    End Sub
    Private Sub cmbteachers2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbteachers2.SelectedIndexChanged
        txtday2.Text = days(cmbteachers2.SelectedIndex)
        txtduty2.Text = duties(cmbteachers2.SelectedIndex)
    End Sub
    Private Sub btnswap2_Click(sender As Object, e As EventArgs) Handles btnswap2.Click
        If cmbteachers.SelectedIndex > -1 And cmbteachers2.SelectedIndex > -1 Then 'checks if there is a selected item in both comboboxes 
            If cmbteachers.SelectedIndex <> cmbteachers2.SelectedIndex Then 'checks if the selected items are not the same 
                swap(duties, cmbteachers.SelectedIndex, cmbteachers2.SelectedIndex) 'swap array values based on selected values 
                txtduty.Text = duties(cmbteachers.SelectedIndex) 'updates text
                txtduty2.Text = duties(cmbteachers2.SelectedIndex)
                MessageBox.Show("swapped")
            Else MessageBox.Show("select two different teachers")
            End If
        Else MessageBox.Show("select teachers")
        End If
    End Sub
    Public Sub swap(ByRef arr() As String, item As Integer, item2 As Integer) 'using sub as this code is used more than once to swap values 
        Dim temp = arr(item) 'creates temp value and swaps two values 
        arr(item) = arr(item2)
        arr(item2) = temp
    End Sub
End Class
