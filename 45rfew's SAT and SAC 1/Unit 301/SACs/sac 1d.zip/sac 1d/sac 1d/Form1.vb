﻿Imports System.Xml
Imports System.IO
Public Class Form1
    Dim fname(9), lname(9), wins(9), fullname(9) 'define arrays as global so they can be used thoughout entire program
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Text = "Member search form"
        Dim file = "CSVMemberFile.csv"
        Dim fname(9), lname(9), wins(9), fullname(9)
        Dim reader As New StreamReader(file), line = reader.ReadLine, r = 0 'defining reader and reading first line to ignore header 
        While True
            line = reader.ReadLine
            If line = Nothing Then Exit While 'loops until a blank line 
            Dim items = line.Split(",") 'splits line by comma 
            fname(r) = items(0)
            lname(r) = items(1) 'appends names to arrays 
            wins(r) = items(items.Length - 1)
            fullname(r) = $"{lname(r).toupper()} {fname(r)}" 'joins names 
            r += 1 'increments rows 
        End While
        Dim sorted = selectionsort(fullname) 'sorts array 
        For i = 0 To sorted.Length - 1 'loops and adds items to listbox 
            lstDisplay.Items.Add(sorted(i))
        Next
        reader.Close() 'closes reader 
    End Sub
    Private Sub searchclick(sender As Object, e As EventArgs) Handles btnsearch.Click
        Dim found = False
        If txtInput.Text <> "" Then 'checks for empty input 
            If Not IsNumeric(txtInput.Text) Then 'checks for type 
                For i = 0 To fullname.Length - 1 'using linear search as there are very few elements in the array 
                    If fullname(i).split(" ")(1) = txtInput.Text Then 'checking if first name is found 
                        found = True
                        MessageBox.Show(fullname(i)) 'displays name 
                        Exit For 'ends loop if found 
                    Else MessageBox.Show("Member not found") 'returns not found if so 
                    End If
                Next
            End If
        End If
    End Sub
    Function selectionsort(arr()) 'using function as it returns a value 
        Dim arrr = arr.Clone() 'creates new clone array 
        Dim n = arrr.Length - 1 'number of elements
        For i = 0 To n
            Dim smallest = i 'selects smallest item
            For j = i + 1 To n 'compare smallest to rest of array
                If arrr(j) < arrr(smallest) Then
                    smallest = j 'update the index for smallest 
                End If
            Next
            If smallest <> i Then
                swap(arrr, smallest, i) 'swaps smallest if it has been found 
            End If
        Next
        Return arrr 'returns sorted array 
    End Function
    Public Sub swap(ByRef arr(), left, right) 'using byref keyword as the sub modifies the array directy 
        Dim temp = arr(left)
        arr(left) = arr(right)
        arr(right) = temp
    End Sub
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtInput.Text = ""
    End Sub
End Class






