﻿'GWAS badminton scoring app
'keeps track of scores for GWAS teams 
'Author: 45rfew
'Date of creation: 3/16/2023
Public Class frm1
    Dim players = {0, 0}, win = {False, False}, time = 0, tick = 0, timeout = 0, lock = False
    'stores player scores in array 
    Public Sub updateScore(player, Optional score = 1) 'using a sub to update scores stored in array and display on textbox
        players(player) += score                        'sub instead of function due to no value being returned 
        If player Then 'set to player score based on player value enter 
            txtplayer2.Text = players(player)
        ElseIf Not player Then
            txtplayer1.Text = players(player)
        End If
        checkScore() 'call sub to check scores 
    End Sub
    Private Sub btnreset_Click(sender As Object, e As EventArgs) Handles btnreset.Click
        players = {0, 0}
        txtplayer1.Text = players(0).ToString
        txtplayer2.Text = players(1).ToString 'resets all text 
        showMsg("Scores reset", 120)
        lblOT.Text = ""
    End Sub
    Private Sub btnplus1_Click(sender As Object, e As EventArgs) Handles btnplus1.Click
        updateScore(0) 'update scores
    End Sub
    Private Sub btnplus2_Click(sender As Object, e As EventArgs) Handles btnplus2.Click
        updateScore(1)
    End Sub
    Private Sub btnsetScore_Click(sender As Object, e As EventArgs) Handles btnsetScore.Click
        If txtplayer1.Text <> "" Then 'check if text is not nothing 
            If Val(txtplayer1.Text) < 100 Then
                If IsNumeric(txtplayer1.Text) Then 'check if text is numeric 
                    players(0) = CInt(txtplayer1.Text)
                    checkScore() 'update and check scores 
                    showMsg("Score set", 120)
                Else
                    showMsg("Enter numeric values only", 120)
                End If
            Else
                showMsg("Score too large")
            End If
        Else showMsg("Enter a value")
        End If

    End Sub
    Private Sub btnsetScore2_Click(sender As Object, e As EventArgs) Handles btnsetScore2.Click
        If txtplayer2.Text <> "" Then
            If Val(txtplayer1.Text) < 100 Then
                If IsNumeric(txtplayer2.Text) Then
                    players(1) = CInt(txtplayer2.Text)
                    checkScore()
                    showMsg("Score set", 120)
                Else
                    showMsg("Enter numeric values only", 120)
                End If
            Else
                showMsg("Score too large")
            End If
        Else showMsg("Enter a value")
        End If
    End Sub
    Public Sub checkScore() 'sub instead of function due to no value being returned 
        For i = 0 To 1 'loops twice due to 2 array values 
            If players(i) >= players(Math.Abs(i - 1)) + 2 And players(i) >= 21 Then 'check if player is more than the other player by 2 points 
                win(i) = True
                lblOT.Text = ($"GAME, PLAYER {i + 1}")
            ElseIf players(i) = 30 Then 'checks if player is at 30 points 
                win(i) = True
                lblOT.Text = ($"GAME, PLAYER {i + 1}")
            End If
            'Select Case players(i) 'decided not to use select case statment as there are only 3 comparisons needed 
            '    Case players(i) >= players(Math.Abs(i - 1)) + 2 And players(i) >= 21 : win(i) = True
            '        MessageBox.Show($"game, player {i}")
            '    Case 30 : win(i) = True
            '        MessageBox.Show($"game, player {i}")
            'End Select
        Next
        If players(0) = players(1) AndAlso players(0) = 20 Then 'if both players are at 20 points displays message 
            lblOT.Text = "At 20 all, the player who gains a 2-point lead first, wins the game" 'outside of loop as only need to be checked once
        End If
    End Sub
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        tmrtick.Start() 'start timer with 1 interval 
        tmrtick.Interval = 1
        lblOT.Text = ""
        lblmsg.Text = ""
    End Sub
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles tmrtick.Tick
        tick += 1
        If tick Mod 60 = 0 Then
            time += 1 'update time every second 
            lbltimer.Text = $"Time: {time} seconds" 'TODO: format time into hours/minutes/seconds 
        End If
        If tick = timeout Then lblmsg.Text = "" 'update message on timeout 
    End Sub
    Public Sub showMsg(msg As String, Optional time As Integer = 120) 'sub instead of function due to no value being returned 
        lblmsg.Text = msg 'shows imputed messgae 
        timeout = tick + time 'sets timeout for message
    End Sub
End Class
