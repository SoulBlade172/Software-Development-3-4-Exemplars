﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btnsetScore = New System.Windows.Forms.Button()
        Me.btnsetScore2 = New System.Windows.Forms.Button()
        Me.btnreset = New System.Windows.Forms.Button()
        Me.txtplayer1 = New System.Windows.Forms.TextBox()
        Me.txtplayer2 = New System.Windows.Forms.TextBox()
        Me.btnplus1 = New System.Windows.Forms.Button()
        Me.btnplus2 = New System.Windows.Forms.Button()
        Me.tmrtick = New System.Windows.Forms.Timer(Me.components)
        Me.lbltitle = New System.Windows.Forms.Label()
        Me.lblmsg = New System.Windows.Forms.Label()
        Me.lblOT = New System.Windows.Forms.Label()
        Me.lbltimer = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnsetScore
        '
        Me.btnsetScore.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnsetScore.Location = New System.Drawing.Point(238, 222)
        Me.btnsetScore.Name = "btnsetScore"
        Me.btnsetScore.Size = New System.Drawing.Size(100, 36)
        Me.btnsetScore.TabIndex = 0
        Me.btnsetScore.Text = "Set Player 1 Score"
        Me.btnsetScore.UseVisualStyleBackColor = False
        '
        'btnsetScore2
        '
        Me.btnsetScore2.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnsetScore2.Location = New System.Drawing.Point(417, 222)
        Me.btnsetScore2.Name = "btnsetScore2"
        Me.btnsetScore2.Size = New System.Drawing.Size(100, 36)
        Me.btnsetScore2.TabIndex = 1
        Me.btnsetScore2.Text = "Set Player 2 Score"
        Me.btnsetScore2.UseVisualStyleBackColor = False
        '
        'btnreset
        '
        Me.btnreset.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnreset.Location = New System.Drawing.Point(323, 338)
        Me.btnreset.Name = "btnreset"
        Me.btnreset.Size = New System.Drawing.Size(100, 35)
        Me.btnreset.TabIndex = 2
        Me.btnreset.Text = "RESET SCORES"
        Me.btnreset.UseVisualStyleBackColor = False
        '
        'txtplayer1
        '
        Me.txtplayer1.Location = New System.Drawing.Point(238, 149)
        Me.txtplayer1.Name = "txtplayer1"
        Me.txtplayer1.Size = New System.Drawing.Size(100, 20)
        Me.txtplayer1.TabIndex = 3
        Me.txtplayer1.Text = "0"
        Me.txtplayer1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtplayer2
        '
        Me.txtplayer2.Location = New System.Drawing.Point(417, 149)
        Me.txtplayer2.Name = "txtplayer2"
        Me.txtplayer2.Size = New System.Drawing.Size(100, 20)
        Me.txtplayer2.TabIndex = 4
        Me.txtplayer2.Text = "0"
        '
        'btnplus1
        '
        Me.btnplus1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnplus1.Location = New System.Drawing.Point(238, 287)
        Me.btnplus1.Name = "btnplus1"
        Me.btnplus1.Size = New System.Drawing.Size(75, 23)
        Me.btnplus1.TabIndex = 5
        Me.btnplus1.Text = "Add +1 "
        Me.btnplus1.UseVisualStyleBackColor = False
        '
        'btnplus2
        '
        Me.btnplus2.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnplus2.Location = New System.Drawing.Point(442, 287)
        Me.btnplus2.Name = "btnplus2"
        Me.btnplus2.Size = New System.Drawing.Size(75, 23)
        Me.btnplus2.TabIndex = 6
        Me.btnplus2.Text = "Add +1"
        Me.btnplus2.UseVisualStyleBackColor = False
        '
        'tmrtick
        '
        '
        'lbltitle
        '
        Me.lbltitle.AutoSize = True
        Me.lbltitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltitle.Location = New System.Drawing.Point(263, 53)
        Me.lbltitle.Name = "lbltitle"
        Me.lbltitle.Size = New System.Drawing.Size(227, 25)
        Me.lbltitle.TabIndex = 7
        Me.lbltitle.Text = "Glen Waverly All Stars"
        '
        'lblmsg
        '
        Me.lblmsg.AutoSize = True
        Me.lblmsg.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblmsg.Location = New System.Drawing.Point(605, 222)
        Me.lblmsg.Name = "lblmsg"
        Me.lblmsg.Size = New System.Drawing.Size(110, 24)
        Me.lblmsg.TabIndex = 8
        Me.lblmsg.Text = "placeholder"
        '
        'lblOT
        '
        Me.lblOT.AutoSize = True
        Me.lblOT.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOT.Location = New System.Drawing.Point(332, 406)
        Me.lblOT.Name = "lblOT"
        Me.lblOT.Size = New System.Drawing.Size(158, 20)
        Me.lblOT.TabIndex = 9
        Me.lblOT.Text = "Overtime placeholder"
        '
        'lbltimer
        '
        Me.lbltimer.AutoSize = True
        Me.lbltimer.Location = New System.Drawing.Point(36, 413)
        Me.lbltimer.Name = "lbltimer"
        Me.lbltimer.Size = New System.Drawing.Size(85, 13)
        Me.lbltimer.TabIndex = 10
        Me.lbltimer.Text = "Time: 0 seconds"
        '
        'frm1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.lbltimer)
        Me.Controls.Add(Me.lblOT)
        Me.Controls.Add(Me.lblmsg)
        Me.Controls.Add(Me.lbltitle)
        Me.Controls.Add(Me.btnplus2)
        Me.Controls.Add(Me.btnplus1)
        Me.Controls.Add(Me.txtplayer2)
        Me.Controls.Add(Me.txtplayer1)
        Me.Controls.Add(Me.btnreset)
        Me.Controls.Add(Me.btnsetScore2)
        Me.Controls.Add(Me.btnsetScore)
        Me.Name = "frm1"
        Me.Text = "GWAS"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnsetScore As Button
    Friend WithEvents btnsetScore2 As Button
    Friend WithEvents btnreset As Button
    Friend WithEvents txtplayer1 As TextBox
    Friend WithEvents txtplayer2 As TextBox
    Friend WithEvents btnplus1 As Button
    Friend WithEvents btnplus2 As Button
    Friend WithEvents tmrtick As Timer
    Friend WithEvents lbltitle As Label
    Friend WithEvents lblmsg As Label
    Friend WithEvents lblOT As Label
    Friend WithEvents lbltimer As Label
End Class
