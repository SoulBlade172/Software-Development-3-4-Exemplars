﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btncalc = New System.Windows.Forms.Button()
        Me.btnclear = New System.Windows.Forms.Button()
        Me.btnend = New System.Windows.Forms.Button()
        Me.txtinput = New System.Windows.Forms.TextBox()
        Me.txtoutput = New System.Windows.Forms.TextBox()
        Me.lblinput = New System.Windows.Forms.Label()
        Me.lblGST = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btncalc
        '
        Me.btncalc.Location = New System.Drawing.Point(244, 237)
        Me.btncalc.Name = "btncalc"
        Me.btncalc.Size = New System.Drawing.Size(322, 113)
        Me.btncalc.TabIndex = 0
        Me.btncalc.Text = "Calculate"
        Me.btncalc.UseVisualStyleBackColor = True
        '
        'btnclear
        '
        Me.btnclear.Location = New System.Drawing.Point(270, 385)
        Me.btnclear.Name = "btnclear"
        Me.btnclear.Size = New System.Drawing.Size(75, 23)
        Me.btnclear.TabIndex = 1
        Me.btnclear.Text = "Clear"
        Me.btnclear.UseVisualStyleBackColor = True
        '
        'btnend
        '
        Me.btnend.Location = New System.Drawing.Point(451, 385)
        Me.btnend.Name = "btnend"
        Me.btnend.Size = New System.Drawing.Size(75, 23)
        Me.btnend.TabIndex = 2
        Me.btnend.Text = "End"
        Me.btnend.UseVisualStyleBackColor = True
        '
        'txtinput
        '
        Me.txtinput.Location = New System.Drawing.Point(451, 116)
        Me.txtinput.Name = "txtinput"
        Me.txtinput.Size = New System.Drawing.Size(100, 20)
        Me.txtinput.TabIndex = 3
        '
        'txtoutput
        '
        Me.txtoutput.Location = New System.Drawing.Point(451, 173)
        Me.txtoutput.Name = "txtoutput"
        Me.txtoutput.ReadOnly = True
        Me.txtoutput.Size = New System.Drawing.Size(100, 20)
        Me.txtoutput.TabIndex = 4
        '
        'lblinput
        '
        Me.lblinput.AutoSize = True
        Me.lblinput.Location = New System.Drawing.Point(267, 116)
        Me.lblinput.Name = "lblinput"
        Me.lblinput.Size = New System.Drawing.Size(70, 13)
        Me.lblinput.TabIndex = 5
        Me.lblinput.Text = "Input Amount"
        '
        'lblGST
        '
        Me.lblGST.AutoSize = True
        Me.lblGST.Location = New System.Drawing.Point(267, 176)
        Me.lblGST.Name = "lblGST"
        Me.lblGST.Size = New System.Drawing.Size(101, 13)
        Me.lblGST.TabIndex = 6
        Me.lblGST.Text = "GST Inclusive Price"
        '
        'frm1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.lblGST)
        Me.Controls.Add(Me.lblinput)
        Me.Controls.Add(Me.txtoutput)
        Me.Controls.Add(Me.txtinput)
        Me.Controls.Add(Me.btnend)
        Me.Controls.Add(Me.btnclear)
        Me.Controls.Add(Me.btncalc)
        Me.Name = "frm1"
        Me.Text = "GST Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btncalc As Button
    Friend WithEvents btnclear As Button
    Friend WithEvents btnend As Button
    Friend WithEvents txtinput As TextBox
    Friend WithEvents txtoutput As TextBox
    Friend WithEvents lblinput As Label
    Friend WithEvents lblGST As Label
End Class
