﻿'GST Calulator 
'converters inputed value to include gst
'date of creation: 3/14/2023
'author: 45rfew
Public Class frm1
    Private Sub btncalc_Click(sender As Object, e As EventArgs) Handles btncalc.Click
        If txtinput.Text IsNot Nothing Then 'checks if input has a value 
            If IsNumeric(txtinput.Text) Then 'check if input is numeric 
                If Math.Log10(Val(txtinput.Text)) < 8 Then 'check is input is less than 100000000 to prevent integer overflow
                    'converts input text to integer to do numeric checks and calculations 
                    If Val(txtinput.Text) >= 0 Then 'check if input is not negative
                        txtoutput.Text = CInt(Math.Round(txtinput.Text * 1.1, 2)).ToString 'displays value to include GST, rounded to 2.dp
                    Else MessageBox.Show("enter positive value")
                        txtinput.Text = "" 'clears inputbox if there are any errors 
                    End If
                Else MessageBox.Show("value too large")
                    txtinput.Text = ""
                End If
            Else MessageBox.Show("only input numbers")
                txtinput.Text = ""
            End If
        Else MessageBox.Show("input a value")
            txtinput.Text = ""
        End If
    End Sub
    Private Sub btnclear_Click(sender As Object, e As EventArgs) Handles btnclear.Click
        txtinput.Text = "" 'clear all textboxes
        txtoutput.Text = ""
    End Sub
    Private Sub btnend_Click(sender As Object, e As EventArgs) Handles btnend.Click
        Me.Close() 'close the program
    End Sub
End Class
