﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnsave = New System.Windows.Forms.Button()
        Me.lstfname = New System.Windows.Forms.ListBox()
        Me.lstlname = New System.Windows.Forms.ListBox()
        Me.lstpostcode = New System.Windows.Forms.ListBox()
        Me.lstjoinDate = New System.Windows.Forms.ListBox()
        Me.lsttournamentsWon = New System.Windows.Forms.ListBox()
        Me.lblfname = New System.Windows.Forms.Label()
        Me.lbllname = New System.Windows.Forms.Label()
        Me.lblpostcode = New System.Windows.Forms.Label()
        Me.lbljoinDate = New System.Windows.Forms.Label()
        Me.lblwon = New System.Windows.Forms.Label()
        Me.lbltitle = New System.Windows.Forms.Label()
        Me.btnclose = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnsave
        '
        Me.btnsave.Location = New System.Drawing.Point(351, 348)
        Me.btnsave.Name = "btnsave"
        Me.btnsave.Size = New System.Drawing.Size(83, 38)
        Me.btnsave.TabIndex = 0
        Me.btnsave.Text = "Save as XML file"
        Me.btnsave.UseVisualStyleBackColor = True
        '
        'lstfname
        '
        Me.lstfname.FormattingEnabled = True
        Me.lstfname.Location = New System.Drawing.Point(35, 141)
        Me.lstfname.Name = "lstfname"
        Me.lstfname.Size = New System.Drawing.Size(120, 186)
        Me.lstfname.TabIndex = 1
        '
        'lstlname
        '
        Me.lstlname.FormattingEnabled = True
        Me.lstlname.Location = New System.Drawing.Point(182, 141)
        Me.lstlname.Name = "lstlname"
        Me.lstlname.Size = New System.Drawing.Size(120, 186)
        Me.lstlname.TabIndex = 2
        '
        'lstpostcode
        '
        Me.lstpostcode.FormattingEnabled = True
        Me.lstpostcode.Location = New System.Drawing.Point(334, 141)
        Me.lstpostcode.Name = "lstpostcode"
        Me.lstpostcode.Size = New System.Drawing.Size(120, 186)
        Me.lstpostcode.TabIndex = 3
        '
        'lstjoinDate
        '
        Me.lstjoinDate.FormattingEnabled = True
        Me.lstjoinDate.Location = New System.Drawing.Point(490, 141)
        Me.lstjoinDate.Name = "lstjoinDate"
        Me.lstjoinDate.Size = New System.Drawing.Size(120, 186)
        Me.lstjoinDate.TabIndex = 4
        '
        'lsttournamentsWon
        '
        Me.lsttournamentsWon.FormattingEnabled = True
        Me.lsttournamentsWon.Location = New System.Drawing.Point(643, 141)
        Me.lsttournamentsWon.Name = "lsttournamentsWon"
        Me.lsttournamentsWon.Size = New System.Drawing.Size(120, 186)
        Me.lsttournamentsWon.TabIndex = 5
        '
        'lblfname
        '
        Me.lblfname.AutoSize = True
        Me.lblfname.Location = New System.Drawing.Point(65, 113)
        Me.lblfname.Name = "lblfname"
        Me.lblfname.Size = New System.Drawing.Size(55, 13)
        Me.lblfname.TabIndex = 6
        Me.lblfname.Text = "First name"
        '
        'lbllname
        '
        Me.lbllname.AutoSize = True
        Me.lbllname.Location = New System.Drawing.Point(217, 113)
        Me.lbllname.Name = "lbllname"
        Me.lbllname.Size = New System.Drawing.Size(55, 13)
        Me.lbllname.TabIndex = 7
        Me.lbllname.Text = "First name"
        '
        'lblpostcode
        '
        Me.lblpostcode.AutoSize = True
        Me.lblpostcode.Location = New System.Drawing.Point(370, 113)
        Me.lblpostcode.Name = "lblpostcode"
        Me.lblpostcode.Size = New System.Drawing.Size(52, 13)
        Me.lblpostcode.TabIndex = 8
        Me.lblpostcode.Text = "Postcode"
        '
        'lbljoinDate
        '
        Me.lbljoinDate.AutoSize = True
        Me.lbljoinDate.Location = New System.Drawing.Point(519, 113)
        Me.lbljoinDate.Name = "lbljoinDate"
        Me.lbljoinDate.Size = New System.Drawing.Size(64, 13)
        Me.lbljoinDate.TabIndex = 9
        Me.lbljoinDate.Text = "Joining date"
        '
        'lblwon
        '
        Me.lblwon.AutoSize = True
        Me.lblwon.Location = New System.Drawing.Point(656, 113)
        Me.lblwon.Name = "lblwon"
        Me.lblwon.Size = New System.Drawing.Size(92, 13)
        Me.lblwon.TabIndex = 10
        Me.lblwon.Text = "Tournaments won"
        '
        'lbltitle
        '
        Me.lbltitle.AutoSize = True
        Me.lbltitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltitle.Location = New System.Drawing.Point(247, 46)
        Me.lbltitle.Name = "lbltitle"
        Me.lbltitle.Size = New System.Drawing.Size(249, 29)
        Me.lbltitle.TabIndex = 11
        Me.lbltitle.Text = "Glen Waverly All Stars"
        '
        'btnclose
        '
        Me.btnclose.Location = New System.Drawing.Point(673, 405)
        Me.btnclose.Name = "btnclose"
        Me.btnclose.Size = New System.Drawing.Size(75, 23)
        Me.btnclose.TabIndex = 12
        Me.btnclose.Text = "Exit"
        Me.btnclose.UseVisualStyleBackColor = True
        '
        'frm1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnclose)
        Me.Controls.Add(Me.lbltitle)
        Me.Controls.Add(Me.lblwon)
        Me.Controls.Add(Me.lbljoinDate)
        Me.Controls.Add(Me.lblpostcode)
        Me.Controls.Add(Me.lbllname)
        Me.Controls.Add(Me.lblfname)
        Me.Controls.Add(Me.lsttournamentsWon)
        Me.Controls.Add(Me.lstjoinDate)
        Me.Controls.Add(Me.lstpostcode)
        Me.Controls.Add(Me.lstlname)
        Me.Controls.Add(Me.lstfname)
        Me.Controls.Add(Me.btnsave)
        Me.Name = "frm1"
        Me.Text = "GWAS export as XML"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnsave As Button
    Friend WithEvents lstfname As ListBox
    Friend WithEvents lstlname As ListBox
    Friend WithEvents lstpostcode As ListBox
    Friend WithEvents lstjoinDate As ListBox
    Friend WithEvents lsttournamentsWon As ListBox
    Friend WithEvents lblfname As Label
    Friend WithEvents lbllname As Label
    Friend WithEvents lblpostcode As Label
    Friend WithEvents lbljoinDate As Label
    Friend WithEvents lblwon As Label
    Friend WithEvents lbltitle As Label
    Friend WithEvents btnclose As Button
End Class
