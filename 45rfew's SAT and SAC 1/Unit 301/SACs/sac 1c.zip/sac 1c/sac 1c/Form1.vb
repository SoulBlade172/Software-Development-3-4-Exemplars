﻿'Export GWAS records to XML file
'saves the player's data to an XML file 
'Author: 45rfew
'Date of creation: 3/17/2023
Imports System.Xml 'imports system's xml functions to allow for reading/writing XML files 
Public Class frm1
    ReadOnly players = {
        {"Dan", "Lin", "3150", "1/3/2010", "10"},
    {"Lee", "Chong", "3976", "4/5/2018", "9"},
    {"Gao", "Ling", "3356", "3/1/2014", "8"},
    {"Taufik", "Hidayat", "3345", "23/4/2020", "7"},
    {"Ruby", "Hartono", "3225", "12/12/2019", "6"},
    {"Li", "Lingwei", "3154", "9/9/2017", "1"},
    {"Tony", "Gunawan", "3456", "23/4/2020", "2"},
    {"Morten", "Hansen", "3111", "3/1/2014", "3"},
    {"Peter", "Gade", "3444", "21/8/2017", "4"},
    {"Han", "Aiping", "3245", "23/5/2020", "5"}
    } 'defining all player data within a multidimensional array; each sub-array contains the player's seperate data 
    'easier to loop through 1 single multidimensional array and easier to read 
    'set to readonly as it is not modified at all during the program 
    'all values within the arrays are strings due to not being required to perform calculations 
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim displays() As ListBox = {lstfname, lstlname, lstpostcode, lstjoinDate, lsttournamentsWon} 'saving all listboxes in an array so that they can be looped through 
        For i = 0 To players.getlength(0) - 1 'loops through the main array 
            For j = 0 To players.getlength(1) - 1 'loops through each sub-array
                displays(j).Items.Add(players(i, j)) 'displays each record on a their seperate listbox 
            Next
        Next
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnsave.Click
        saveXML("GWAS") 'calling function to save on click 
    End Sub
    Public Function saveXML(name)
        Dim writersettings As XmlWriterSettings = New XmlWriterSettings With {.Indent = True} 'adds indent 
        Try
            Dim writer As XmlWriter = XmlWriter.Create($"{name}.xml", writersettings) 'creating XML writer 
            Dim labels = {"FirstName", "LastName", "Postcode", "JoiningDate", "TWon"} 'listing all XML element labels so they can be looped through 
            writer.WriteStartDocument()
            writer.WriteStartElement("Memberlist") 'starts memberlist element - root 
            For j = 0 To players.GetLength(0) - 1 'loops through players array 
                writer.WriteStartElement("Members") 'creations element members in which all seperate player data is saved within 
                For i = 0 To labels.Length - 1 'loops through labels array 
                    writer.WriteElementString(labels(i), players(j, i)) 'writes to XML file 
                Next
                writer.WriteEndElement() 'ends member element, loops until all players have been added to XML doc 
            Next
            writer.WriteEndElement() 'ends the memberlist element - root 
            writer.WriteEndDocument() 'ends the XML doc 
            writer.Flush() 'flushes writer 
            writer.Close() 'closes writer
            Return MessageBox.Show("XML file saved in project bin > debug folder") 'shows messagebox informing of creation 
        Catch ex As Exception
            Return MessageBox.Show("an error occurred trying to save XML file") 'shows messagebox informing of error if an error occures 
        End Try
    End Function
    Private Sub btnclose_Click(sender As Object, e As EventArgs) Handles btnclose.Click
        Me.Close() 'closes program 
    End Sub
End Class


