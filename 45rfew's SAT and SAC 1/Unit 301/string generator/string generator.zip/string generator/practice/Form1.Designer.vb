﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.timer = New System.Windows.Forms.Timer(Me.components)
        Me.btnTimerStart = New System.Windows.Forms.Button()
        Me.lblTimer = New System.Windows.Forms.Label()
        Me.lblRandText = New System.Windows.Forms.Label()
        Me.lstOutput = New System.Windows.Forms.ListBox()
        Me.txtStrLen = New System.Windows.Forms.TextBox()
        Me.lblCharNum = New System.Windows.Forms.Label()
        Me.lblCharacters = New System.Windows.Forms.Label()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.txtRandInput = New System.Windows.Forms.TextBox()
        Me.btnAddRandom = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnGenerate = New System.Windows.Forms.Button()
        Me.pi = New System.Windows.Forms.Label()
        Me.btnClearOutput = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'timer
        '
        '
        'btnTimerStart
        '
        Me.btnTimerStart.Location = New System.Drawing.Point(592, 126)
        Me.btnTimerStart.Name = "btnTimerStart"
        Me.btnTimerStart.Size = New System.Drawing.Size(75, 23)
        Me.btnTimerStart.TabIndex = 0
        Me.btnTimerStart.Text = "Start timer"
        Me.btnTimerStart.UseVisualStyleBackColor = True
        '
        'lblTimer
        '
        Me.lblTimer.AutoSize = True
        Me.lblTimer.Location = New System.Drawing.Point(610, 100)
        Me.lblTimer.Name = "lblTimer"
        Me.lblTimer.Size = New System.Drawing.Size(29, 13)
        Me.lblTimer.TabIndex = 1
        Me.lblTimer.Text = "timer"
        '
        'lblRandText
        '
        Me.lblRandText.AutoSize = True
        Me.lblRandText.Location = New System.Drawing.Point(142, 100)
        Me.lblRandText.Name = "lblRandText"
        Me.lblRandText.Size = New System.Drawing.Size(114, 13)
        Me.lblRandText.TabIndex = 2
        Me.lblRandText.Text = "Last generated strings:"
        '
        'lstOutput
        '
        Me.lstOutput.FormattingEnabled = True
        Me.lstOutput.HorizontalScrollbar = True
        Me.lstOutput.Location = New System.Drawing.Point(54, 126)
        Me.lstOutput.Margin = New System.Windows.Forms.Padding(2)
        Me.lstOutput.Name = "lstOutput"
        Me.lstOutput.Size = New System.Drawing.Size(337, 316)
        Me.lstOutput.TabIndex = 3
        '
        'txtStrLen
        '
        Me.txtStrLen.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtStrLen.Location = New System.Drawing.Point(604, 194)
        Me.txtStrLen.Margin = New System.Windows.Forms.Padding(2)
        Me.txtStrLen.Name = "txtStrLen"
        Me.txtStrLen.Size = New System.Drawing.Size(52, 13)
        Me.txtStrLen.TabIndex = 12
        Me.txtStrLen.Text = "26"
        Me.txtStrLen.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblCharNum
        '
        Me.lblCharNum.AutoSize = True
        Me.lblCharNum.Location = New System.Drawing.Point(574, 179)
        Me.lblCharNum.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblCharNum.Name = "lblCharNum"
        Me.lblCharNum.Size = New System.Drawing.Size(110, 13)
        Me.lblCharNum.TabIndex = 5
        Me.lblCharNum.Text = "number of characters:"
        '
        'lblCharacters
        '
        Me.lblCharacters.AutoSize = True
        Me.lblCharacters.Location = New System.Drawing.Point(446, 319)
        Me.lblCharacters.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblCharacters.Name = "lblCharacters"
        Me.lblCharacters.Size = New System.Drawing.Size(62, 13)
        Me.lblCharacters.TabIndex = 8
        Me.lblCharacters.Text = "placeholder"
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.Location = New System.Drawing.Point(531, 49)
        Me.lblTitle.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(218, 24)
        Me.lblTitle.TabIndex = 9
        Me.lblTitle.Text = "Random string generator"
        '
        'txtRandInput
        '
        Me.txtRandInput.BackColor = System.Drawing.SystemColors.Control
        Me.txtRandInput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtRandInput.Location = New System.Drawing.Point(568, 249)
        Me.txtRandInput.Name = "txtRandInput"
        Me.txtRandInput.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.txtRandInput.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal
        Me.txtRandInput.Size = New System.Drawing.Size(100, 20)
        Me.txtRandInput.TabIndex = 10
        Me.txtRandInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'btnAddRandom
        '
        Me.btnAddRandom.Location = New System.Drawing.Point(674, 249)
        Me.btnAddRandom.Name = "btnAddRandom"
        Me.btnAddRandom.Size = New System.Drawing.Size(75, 23)
        Me.btnAddRandom.TabIndex = 11
        Me.btnAddRandom.Text = "Add to pool"
        Me.btnAddRandom.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(755, 249)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 12
        Me.btnClear.Text = "Clear all"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnGenerate
        '
        Me.btnGenerate.Location = New System.Drawing.Point(592, 287)
        Me.btnGenerate.Name = "btnGenerate"
        Me.btnGenerate.Size = New System.Drawing.Size(75, 23)
        Me.btnGenerate.TabIndex = 13
        Me.btnGenerate.Text = "Generate string"
        Me.btnGenerate.UseVisualStyleBackColor = True
        '
        'pi
        '
        Me.pi.AutoSize = True
        Me.pi.Location = New System.Drawing.Point(610, 467)
        Me.pi.Name = "pi"
        Me.pi.Size = New System.Drawing.Size(24, 13)
        Me.pi.TabIndex = 1400
        Me.pi.Text = "text"
        '
        'btnClearOutput
        '
        Me.btnClearOutput.Location = New System.Drawing.Point(181, 457)
        Me.btnClearOutput.Name = "btnClearOutput"
        Me.btnClearOutput.Size = New System.Drawing.Size(75, 23)
        Me.btnClearOutput.TabIndex = 1402
        Me.btnClearOutput.Text = "Clear"
        Me.btnClearOutput.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ClientSize = New System.Drawing.Size(1303, 558)
        Me.Controls.Add(Me.btnClearOutput)
        Me.Controls.Add(Me.pi)
        Me.Controls.Add(Me.btnGenerate)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnAddRandom)
        Me.Controls.Add(Me.txtRandInput)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.lblCharacters)
        Me.Controls.Add(Me.lblCharNum)
        Me.Controls.Add(Me.lstOutput)
        Me.Controls.Add(Me.lblRandText)
        Me.Controls.Add(Me.lblTimer)
        Me.Controls.Add(Me.btnTimerStart)
        Me.Controls.Add(Me.txtStrLen)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents timer As Timer
    Friend WithEvents btnTimerStart As Button
    Friend WithEvents lblTimer As Label
    Friend WithEvents lblRandText As Label
    Friend WithEvents lstOutput As ListBox
    Friend WithEvents txtStrLen As TextBox
    Friend WithEvents lblCharNum As Label
    Friend WithEvents lblCharacters As Label
    Friend WithEvents lblTitle As Label
    Friend WithEvents txtRandInput As TextBox
    Friend WithEvents btnAddRandom As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnGenerate As Button
    Friend WithEvents pi As Label
    Friend WithEvents btnClearOutput As Button
End Class
