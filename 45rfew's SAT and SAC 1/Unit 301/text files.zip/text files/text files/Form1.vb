﻿Public Class Form1
    Dim filename As String = "C:\Users\Frankie Lin\OneDrive\Documents\it\a.txt"
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim textline As String
        If System.IO.File.Exists(filename) Then
            Dim arr = {"ddasd", "sdsdas", "asdqdqw", "dcerw", "34423rdews"}
            Dim objWriter As New System.IO.StreamWriter(filename, False)
            For Each i In arr
                objWriter.WriteLine(i)
            Next
            objWriter.Close()
            MessageBox.Show("text written to file")
        Else MessageBox.Show($"{filename} does not exist")
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim textline As String
        If System.IO.File.Exists(filename) Then
            Dim objreader As New System.IO.StreamReader(filename, False)
            Do While objreader.Peek() <> -1
                textline &= objreader.ReadLine() & vbNewLine
            Loop
            RichTextBox1.Text = textline
        Else MessageBox.Show($"{filename} does not exist")
        End If
    End Sub
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim filecopy = filename
        Dim newcopy = filename.Replace(".", "new.")
        If System.IO.File.Exists(filecopy) Then
            If System.IO.File.Exists(newcopy) Then
                System.IO.File.Copy(filecopy.Replace("new", "new2"), newcopy)
            Else
                System.IO.File.Copy(filecopy, newcopy)
            End If
            MessageBox.Show("file copied")
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim filemove = filename
        Dim location = "C:\Users\Frankie Lin\OneDrive\Documents\it\New folder\New Text Document.txt"
        If System.IO.File.Exists(filemove) Then
            System.IO.File.Move(filemove, location)
            MessageBox.Show("file moved")
        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Dim delete = "C:\Users\Frankie Lin\OneDrive\Documents\it\New folder\New Text Document.txt"
        If System.IO.File.Exists(delete) Then
            System.IO.File.Delete(delete)
        End If
    End Sub
End Class

