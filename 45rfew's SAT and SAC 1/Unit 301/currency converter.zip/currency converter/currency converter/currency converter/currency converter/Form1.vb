﻿Public Class z
    Private Sub btnConvert_Click(sender As Object, e As EventArgs) Handles btnConvert.Click
        Dim currency() As RadioButton = {optUsd, optYen, optEuro}, rates = {1.4, 0.1, 1.8}, rate As Double = 0
        For i = 0 To 2
            If currency(i).Checked Then rate = rates(i) 'searches through all radio buttons and sets rate to the currency checked  
        Next
        If IsNumeric(txtInput.Text) Then 'filters out characters 
            Try
                If CInt(txtInput.Text) > 0 Then 'filters any negatives 
                    lblOutput.Text = Math.Abs(Math.Round(CInt(txtInput.Text) * rate, 2)) 'converts the currency and displays the value on label and rounds to 2dp
                Else MessageBox.Show("enter number between 0 and 100000000")
                    txtInput.Clear() 'clears textbox if any negative values 
                End If
            Catch ex As Exception
                MessageBox.Show("enter a valid value") 'if it is not a valid value clears textbox 
                txtInput.Clear()
            End Try
        Else
            MessageBox.Show("enter a valid value") 'clear textbox if any characters or nullable value 
            txtInput.Clear()
        End If
    End Sub
    Private Sub txtInput_TextChanged(sender As Object, e As EventArgs) Handles txtInput.TextChanged
        If IsNumeric(txtInput.Text) Then
            If Math.Log10(CInt(txtInput.Text)) > 8 Then 'disallows numbers larger than 100000000.0 to prevent integer overflow 
                MessageBox.Show("input too large")
                txtInput.Clear()
            End If
        End If
    End Sub
End Class
