﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class z
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lbldesc1 = New System.Windows.Forms.Label()
        Me.lblDesc = New System.Windows.Forms.Label()
        Me.btnConvert = New System.Windows.Forms.Button()
        Me.lblOutput = New System.Windows.Forms.Label()
        Me.optUsd = New System.Windows.Forms.RadioButton()
        Me.gpbCurrency = New System.Windows.Forms.GroupBox()
        Me.optEuro = New System.Windows.Forms.RadioButton()
        Me.optYen = New System.Windows.Forms.RadioButton()
        Me.txtInput = New System.Windows.Forms.TextBox()
        Me.gpbCurrency.SuspendLayout()
        Me.SuspendLayout()
        '
        'lbldesc1
        '
        Me.lbldesc1.AutoSize = True
        Me.lbldesc1.Location = New System.Drawing.Point(152, 129)
        Me.lbldesc1.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lbldesc1.Name = "lbldesc1"
        Me.lbldesc1.Size = New System.Drawing.Size(408, 25)
        Me.lbldesc1.TabIndex = 0
        Me.lbldesc1.Text = "select the currency you wanna convert  to aud"
        '
        'lblDesc
        '
        Me.lblDesc.AutoSize = True
        Me.lblDesc.Location = New System.Drawing.Point(152, 316)
        Me.lblDesc.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblDesc.Name = "lblDesc"
        Me.lblDesc.Size = New System.Drawing.Size(413, 25)
        Me.lblDesc.TabIndex = 1
        Me.lblDesc.Text = "enter the amount of foreign currency to convert"
        '
        'btnConvert
        '
        Me.btnConvert.Location = New System.Drawing.Point(198, 473)
        Me.btnConvert.Margin = New System.Windows.Forms.Padding(6)
        Me.btnConvert.Name = "btnConvert"
        Me.btnConvert.Size = New System.Drawing.Size(222, 96)
        Me.btnConvert.TabIndex = 2
        Me.btnConvert.Text = "click to convert"
        Me.btnConvert.UseVisualStyleBackColor = True
        '
        'lblOutput
        '
        Me.lblOutput.AutoSize = True
        Me.lblOutput.Location = New System.Drawing.Point(940, 509)
        Me.lblOutput.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblOutput.Name = "lblOutput"
        Me.lblOutput.Size = New System.Drawing.Size(23, 25)
        Me.lblOutput.TabIndex = 3
        Me.lblOutput.Text = "0"
        '
        'optUsd
        '
        Me.optUsd.AutoSize = True
        Me.optUsd.Checked = True
        Me.optUsd.Location = New System.Drawing.Point(0, 31)
        Me.optUsd.Margin = New System.Windows.Forms.Padding(6)
        Me.optUsd.Name = "optUsd"
        Me.optUsd.Size = New System.Drawing.Size(69, 29)
        Me.optUsd.TabIndex = 4
        Me.optUsd.TabStop = True
        Me.optUsd.Text = "usd"
        Me.optUsd.UseVisualStyleBackColor = True
        '
        'gpbCurrency
        '
        Me.gpbCurrency.Controls.Add(Me.optEuro)
        Me.gpbCurrency.Controls.Add(Me.optYen)
        Me.gpbCurrency.Controls.Add(Me.optUsd)
        Me.gpbCurrency.Location = New System.Drawing.Point(887, 129)
        Me.gpbCurrency.Margin = New System.Windows.Forms.Padding(6)
        Me.gpbCurrency.Name = "gpbCurrency"
        Me.gpbCurrency.Padding = New System.Windows.Forms.Padding(6)
        Me.gpbCurrency.Size = New System.Drawing.Size(502, 186)
        Me.gpbCurrency.TabIndex = 5
        Me.gpbCurrency.TabStop = False
        Me.gpbCurrency.Text = "box"
        '
        'optEuro
        '
        Me.optEuro.AutoSize = True
        Me.optEuro.Location = New System.Drawing.Point(0, 118)
        Me.optEuro.Margin = New System.Windows.Forms.Padding(6)
        Me.optEuro.Name = "optEuro"
        Me.optEuro.Size = New System.Drawing.Size(76, 29)
        Me.optEuro.TabIndex = 6
        Me.optEuro.Text = "euro"
        Me.optEuro.UseVisualStyleBackColor = True
        '
        'optYen
        '
        Me.optYen.AutoSize = True
        Me.optYen.Location = New System.Drawing.Point(0, 74)
        Me.optYen.Margin = New System.Windows.Forms.Padding(6)
        Me.optYen.Name = "optYen"
        Me.optYen.Size = New System.Drawing.Size(69, 29)
        Me.optYen.TabIndex = 5
        Me.optYen.Text = "yen"
        Me.optYen.UseVisualStyleBackColor = True
        '
        'txtInput
        '
        Me.txtInput.Location = New System.Drawing.Point(887, 316)
        Me.txtInput.Margin = New System.Windows.Forms.Padding(6)
        Me.txtInput.Name = "txtInput"
        Me.txtInput.Size = New System.Drawing.Size(180, 29)
        Me.txtInput.TabIndex = 6
        Me.txtInput.Text = "0"
        '
        'z
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(11.0!, 24.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1467, 831)
        Me.Controls.Add(Me.txtInput)
        Me.Controls.Add(Me.gpbCurrency)
        Me.Controls.Add(Me.lblOutput)
        Me.Controls.Add(Me.btnConvert)
        Me.Controls.Add(Me.lblDesc)
        Me.Controls.Add(Me.lbldesc1)
        Me.Margin = New System.Windows.Forms.Padding(6)
        Me.Name = "z"
        Me.Text = "currency converter"
        Me.gpbCurrency.ResumeLayout(False)
        Me.gpbCurrency.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbldesc1 As Label
    Friend WithEvents lblDesc As Label
    Friend WithEvents btnConvert As Button
    Friend WithEvents lblOutput As Label
    Friend WithEvents optUsd As RadioButton
    Friend WithEvents gpbCurrency As GroupBox
    Friend WithEvents optEuro As RadioButton
    Friend WithEvents optYen As RadioButton
    Friend WithEvents txtInput As TextBox
End Class
