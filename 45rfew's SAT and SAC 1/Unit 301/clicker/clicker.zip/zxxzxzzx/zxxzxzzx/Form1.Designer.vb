﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class clicker
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblYeetus = New System.Windows.Forms.Label()
        Me.btnUpgrade1 = New System.Windows.Forms.Button()
        Me.btnupgrade2 = New System.Windows.Forms.Button()
        Me.btnupgrade3 = New System.Windows.Forms.Button()
        Me.grpupgrades = New System.Windows.Forms.GroupBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.lbldpsind = New System.Windows.Forms.Label()
        Me.lblupgrade2 = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.lblbonus = New System.Windows.Forms.Label()
        Me.lblupgrade3 = New System.Windows.Forms.Label()
        Me.grpupgrade1 = New System.Windows.Forms.GroupBox()
        Me.lbldamageind = New System.Windows.Forms.Label()
        Me.lblupgrade1 = New System.Windows.Forms.Label()
        Me.lbldamage = New System.Windows.Forms.Label()
        Me.lbldps = New System.Windows.Forms.Label()
        Me.lblmultiplier = New System.Windows.Forms.Label()
        Me.pbmain = New System.Windows.Forms.PictureBox()
        Me.grpupgrades.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.grpupgrade1.SuspendLayout()
        CType(Me.pbmain, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Timer1
        '
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(941, 46)
        Me.Label1.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(23, 25)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "0"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(1049, 46)
        Me.Label2.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(23, 25)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "0"
        '
        'lblYeetus
        '
        Me.lblYeetus.AutoSize = True
        Me.lblYeetus.Location = New System.Drawing.Point(220, 37)
        Me.lblYeetus.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblYeetus.Name = "lblYeetus"
        Me.lblYeetus.Size = New System.Drawing.Size(86, 25)
        Me.lblYeetus.TabIndex = 3
        Me.lblYeetus.Text = "0 yeetus"
        '
        'btnUpgrade1
        '
        Me.btnUpgrade1.Location = New System.Drawing.Point(202, 30)
        Me.btnUpgrade1.Margin = New System.Windows.Forms.Padding(6)
        Me.btnUpgrade1.Name = "btnUpgrade1"
        Me.btnUpgrade1.Size = New System.Drawing.Size(138, 42)
        Me.btnUpgrade1.TabIndex = 4
        Me.btnUpgrade1.Text = "0"
        Me.btnUpgrade1.UseVisualStyleBackColor = True
        '
        'btnupgrade2
        '
        Me.btnupgrade2.Location = New System.Drawing.Point(202, 30)
        Me.btnupgrade2.Margin = New System.Windows.Forms.Padding(6)
        Me.btnupgrade2.Name = "btnupgrade2"
        Me.btnupgrade2.Size = New System.Drawing.Size(138, 42)
        Me.btnupgrade2.TabIndex = 5
        Me.btnupgrade2.Text = "0"
        Me.btnupgrade2.UseVisualStyleBackColor = True
        '
        'btnupgrade3
        '
        Me.btnupgrade3.Location = New System.Drawing.Point(202, 30)
        Me.btnupgrade3.Margin = New System.Windows.Forms.Padding(6)
        Me.btnupgrade3.Name = "btnupgrade3"
        Me.btnupgrade3.Size = New System.Drawing.Size(138, 42)
        Me.btnupgrade3.TabIndex = 6
        Me.btnupgrade3.Text = "0"
        Me.btnupgrade3.UseVisualStyleBackColor = True
        '
        'grpupgrades
        '
        Me.grpupgrades.Controls.Add(Me.GroupBox3)
        Me.grpupgrades.Controls.Add(Me.GroupBox4)
        Me.grpupgrades.Controls.Add(Me.grpupgrade1)
        Me.grpupgrades.Location = New System.Drawing.Point(684, 120)
        Me.grpupgrades.Margin = New System.Windows.Forms.Padding(6)
        Me.grpupgrades.Name = "grpupgrades"
        Me.grpupgrades.Padding = New System.Windows.Forms.Padding(6)
        Me.grpupgrades.Size = New System.Drawing.Size(436, 598)
        Me.grpupgrades.TabIndex = 7
        Me.grpupgrades.TabStop = False
        Me.grpupgrades.Text = "upgrades"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.lbldpsind)
        Me.GroupBox3.Controls.Add(Me.lblupgrade2)
        Me.GroupBox3.Controls.Add(Me.btnupgrade2)
        Me.GroupBox3.Location = New System.Drawing.Point(11, 236)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(6)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(6)
        Me.GroupBox3.Size = New System.Drawing.Size(363, 133)
        Me.GroupBox3.TabIndex = 10
        Me.GroupBox3.TabStop = False
        '
        'lbldpsind
        '
        Me.lbldpsind.AutoSize = True
        Me.lbldpsind.Location = New System.Drawing.Point(46, 78)
        Me.lbldpsind.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lbldpsind.Name = "lbldpsind"
        Me.lbldpsind.Size = New System.Drawing.Size(201, 25)
        Me.lbldpsind.TabIndex = 11
        Me.lbldpsind.Text = "0 damage per second"
        '
        'lblupgrade2
        '
        Me.lblupgrade2.AutoSize = True
        Me.lblupgrade2.Location = New System.Drawing.Point(53, 30)
        Me.lblupgrade2.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblupgrade2.Name = "lblupgrade2"
        Me.lblupgrade2.Size = New System.Drawing.Size(78, 25)
        Me.lblupgrade2.TabIndex = 8
        Me.lblupgrade2.Text = "ham - 0"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.lblbonus)
        Me.GroupBox4.Controls.Add(Me.lblupgrade3)
        Me.GroupBox4.Controls.Add(Me.btnupgrade3)
        Me.GroupBox4.Location = New System.Drawing.Point(11, 443)
        Me.GroupBox4.Margin = New System.Windows.Forms.Padding(6)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Padding = New System.Windows.Forms.Padding(6)
        Me.GroupBox4.Size = New System.Drawing.Size(363, 144)
        Me.GroupBox4.TabIndex = 11
        Me.GroupBox4.TabStop = False
        '
        'lblbonus
        '
        Me.lblbonus.AutoSize = True
        Me.lblbonus.Location = New System.Drawing.Point(46, 78)
        Me.lblbonus.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblbonus.Name = "lblbonus"
        Me.lblbonus.Size = New System.Drawing.Size(176, 25)
        Me.lblbonus.TabIndex = 12
        Me.lblbonus.Text = "0% bonus damage"
        '
        'lblupgrade3
        '
        Me.lblupgrade3.AutoSize = True
        Me.lblupgrade3.Location = New System.Drawing.Point(46, 30)
        Me.lblupgrade3.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblupgrade3.Name = "lblupgrade3"
        Me.lblupgrade3.Size = New System.Drawing.Size(86, 25)
        Me.lblupgrade3.TabIndex = 9
        Me.lblupgrade3.Text = "pizza - 0"
        '
        'grpupgrade1
        '
        Me.grpupgrade1.Controls.Add(Me.lbldamageind)
        Me.grpupgrade1.Controls.Add(Me.lblupgrade1)
        Me.grpupgrade1.Controls.Add(Me.btnUpgrade1)
        Me.grpupgrade1.Location = New System.Drawing.Point(11, 35)
        Me.grpupgrade1.Margin = New System.Windows.Forms.Padding(6)
        Me.grpupgrade1.Name = "grpupgrade1"
        Me.grpupgrade1.Padding = New System.Windows.Forms.Padding(6)
        Me.grpupgrade1.Size = New System.Drawing.Size(363, 146)
        Me.grpupgrade1.TabIndex = 9
        Me.grpupgrade1.TabStop = False
        '
        'lbldamageind
        '
        Me.lbldamageind.AutoSize = True
        Me.lbldamageind.Location = New System.Drawing.Point(53, 83)
        Me.lbldamageind.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lbldamageind.Name = "lbldamageind"
        Me.lbldamageind.Size = New System.Drawing.Size(175, 25)
        Me.lbldamageind.TabIndex = 10
        Me.lbldamageind.Text = "1 damage per click"
        '
        'lblupgrade1
        '
        Me.lblupgrade1.AutoSize = True
        Me.lblupgrade1.Location = New System.Drawing.Point(53, 30)
        Me.lblupgrade1.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblupgrade1.Name = "lblupgrade1"
        Me.lblupgrade1.Size = New System.Drawing.Size(78, 25)
        Me.lblupgrade1.TabIndex = 7
        Me.lblupgrade1.Text = "click - 0"
        '
        'lbldamage
        '
        Me.lbldamage.AutoSize = True
        Me.lbldamage.Location = New System.Drawing.Point(220, 82)
        Me.lbldamage.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lbldamage.Name = "lbldamage"
        Me.lbldamage.Size = New System.Drawing.Size(99, 25)
        Me.lbldamage.TabIndex = 8
        Me.lbldamage.Text = "1 damage"
        '
        'lbldps
        '
        Me.lbldps.AutoSize = True
        Me.lbldps.Location = New System.Drawing.Point(220, 120)
        Me.lbldps.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lbldps.Name = "lbldps"
        Me.lbldps.Size = New System.Drawing.Size(60, 25)
        Me.lbldps.TabIndex = 9
        Me.lbldps.Text = "0 dps"
        '
        'lblmultiplier
        '
        Me.lblmultiplier.AutoSize = True
        Me.lblmultiplier.Location = New System.Drawing.Point(220, 164)
        Me.lblmultiplier.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblmultiplier.Name = "lblmultiplier"
        Me.lblmultiplier.Size = New System.Drawing.Size(149, 25)
        Me.lblmultiplier.TabIndex = 10
        Me.lblmultiplier.Text = "100% multiplier "
        '
        'pbmain
        '
        Me.pbmain.Image = Global.zxxzxzzx.My.Resources.Resources._5812_yeetus
        Me.pbmain.Location = New System.Drawing.Point(106, 238)
        Me.pbmain.Margin = New System.Windows.Forms.Padding(6)
        Me.pbmain.Name = "pbmain"
        Me.pbmain.Size = New System.Drawing.Size(421, 415)
        Me.pbmain.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pbmain.TabIndex = 2
        Me.pbmain.TabStop = False
        '
        'clicker
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(11.0!, 24.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1965, 831)
        Me.Controls.Add(Me.lblmultiplier)
        Me.Controls.Add(Me.lbldps)
        Me.Controls.Add(Me.lbldamage)
        Me.Controls.Add(Me.grpupgrades)
        Me.Controls.Add(Me.lblYeetus)
        Me.Controls.Add(Me.pbmain)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Margin = New System.Windows.Forms.Padding(6)
        Me.Name = "clicker"
        Me.Text = "yeetus clicker"
        Me.grpupgrades.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.grpupgrade1.ResumeLayout(False)
        Me.grpupgrade1.PerformLayout()
        CType(Me.pbmain, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Timer1 As Timer
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Public WithEvents pbmain As PictureBox
    Friend WithEvents lblYeetus As Label
    Friend WithEvents btnUpgrade1 As Button
    Friend WithEvents btnupgrade2 As Button
    Friend WithEvents btnupgrade3 As Button
    Friend WithEvents grpupgrades As GroupBox
    Friend WithEvents lblupgrade3 As Label
    Friend WithEvents lblupgrade2 As Label
    Friend WithEvents lblupgrade1 As Label
    Friend WithEvents lbldamage As Label
    Friend WithEvents lbldamageind As Label
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents grpupgrade1 As GroupBox
    Friend WithEvents lbldpsind As Label
    Friend WithEvents lbldps As Label
    Friend WithEvents lblbonus As Label
    Friend WithEvents lblmultiplier As Label
End Class
