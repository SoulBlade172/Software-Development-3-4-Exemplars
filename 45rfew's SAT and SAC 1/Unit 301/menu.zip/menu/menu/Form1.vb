﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ViewTextBoxesToolStripMenuItem.Checked = True
    End Sub
    Private Sub mnuExit_Click(sender As Object, e As EventArgs) Handles mnuExit.Click
        Me.Close()
    End Sub
    Private Sub OpenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OpenToolStripMenuItem.Click
        openFD.Title = "Open image"
        openFD.Filter = "jpegs|*.jpg|gifs|*.gif|Bitmaps|*.bmp"
        openFD.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)
        Dim filename As String
        Dim opened As Integer = openFD.ShowDialog()
        If opened <> DialogResult.Cancel Then
            filename = openFD.FileName
            PictureBox1.Image = Image.FromFile(filename)
            openFD.Reset()
        End If
    End Sub
    Private Sub SaveToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaveToolStripMenuItem.Click
        saveFD.InitialDirectory = Environment.GetEnvironmentVariable(Environment.SpecialFolder.MyDocuments)
        saveFD.Title = "Save File"
        saveFD.FileName = "file name"
        saveFD.OverwritePrompt = True
        saveFD.ShowDialog()
    End Sub
    Private Sub CopyToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CopyToolStripMenuItem.Click
        TextBox1.Copy()
    End Sub
    Private Sub PasteToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PasteToolStripMenuItem.Click
        TextBox2.Paste()
    End Sub
    Private Sub CutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CutToolStripMenuItem.Click
        TextBox1.Cut()
    End Sub
    Private Sub UndoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UndoToolStripMenuItem.Click
        TextBox1.Undo()
    End Sub
    Private Sub ViewTextBoxesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ViewTextBoxesToolStripMenuItem.Click
        ViewTextBoxesToolStripMenuItem.Checked = Not ViewTextBoxesToolStripMenuItem.Checked
        If ViewTextBoxesToolStripMenuItem.Checked Then
            TextBox1.Visible = True
            TextBox2.Visible = True
        Else
            TextBox1.Visible = False
            TextBox2.Visible = False
        End If
    End Sub
End Class
