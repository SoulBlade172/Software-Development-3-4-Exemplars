﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frm1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btnopen = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.btnsave = New System.Windows.Forms.Button()
        Me.btnadd = New System.Windows.Forms.Button()
        Me.txtaddinput = New System.Windows.Forms.TextBox()
        Me.btnclear = New System.Windows.Forms.Button()
        Me.cmbcolumns = New System.Windows.Forms.ComboBox()
        Me.txtupdatename = New System.Windows.Forms.TextBox()
        Me.btnupdate = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.lblmessage = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnopen
        '
        Me.btnopen.Location = New System.Drawing.Point(211, 181)
        Me.btnopen.Name = "btnopen"
        Me.btnopen.Size = New System.Drawing.Size(75, 23)
        Me.btnopen.TabIndex = 0
        Me.btnopen.Text = "open"
        Me.btnopen.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btnopen.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToOrderColumns = True
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(317, 12)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersWidth = 72
        Me.DataGridView1.Size = New System.Drawing.Size(82, 35)
        Me.DataGridView1.TabIndex = 3
        '
        'btnsave
        '
        Me.btnsave.Location = New System.Drawing.Point(211, 211)
        Me.btnsave.Name = "btnsave"
        Me.btnsave.Size = New System.Drawing.Size(75, 23)
        Me.btnsave.TabIndex = 4
        Me.btnsave.Text = "save"
        Me.btnsave.UseVisualStyleBackColor = True
        '
        'btnadd
        '
        Me.btnadd.Location = New System.Drawing.Point(141, 405)
        Me.btnadd.Name = "btnadd"
        Me.btnadd.Size = New System.Drawing.Size(75, 39)
        Me.btnadd.TabIndex = 5
        Me.btnadd.Text = "add new column:"
        Me.btnadd.UseVisualStyleBackColor = True
        '
        'txtaddinput
        '
        Me.txtaddinput.Location = New System.Drawing.Point(221, 417)
        Me.txtaddinput.Margin = New System.Windows.Forms.Padding(2)
        Me.txtaddinput.Name = "txtaddinput"
        Me.txtaddinput.Size = New System.Drawing.Size(56, 20)
        Me.txtaddinput.TabIndex = 6
        '
        'btnclear
        '
        Me.btnclear.Location = New System.Drawing.Point(211, 240)
        Me.btnclear.Name = "btnclear"
        Me.btnclear.Size = New System.Drawing.Size(75, 23)
        Me.btnclear.TabIndex = 7
        Me.btnclear.Text = "clear"
        Me.btnclear.UseVisualStyleBackColor = True
        '
        'cmbcolumns
        '
        Me.cmbcolumns.FormattingEnabled = True
        Me.cmbcolumns.Location = New System.Drawing.Point(25, 338)
        Me.cmbcolumns.Name = "cmbcolumns"
        Me.cmbcolumns.Size = New System.Drawing.Size(135, 21)
        Me.cmbcolumns.TabIndex = 9
        Me.cmbcolumns.Text = "select column to rename"
        '
        'txtupdatename
        '
        Me.txtupdatename.Location = New System.Drawing.Point(17, 309)
        Me.txtupdatename.Margin = New System.Windows.Forms.Padding(2)
        Me.txtupdatename.Name = "txtupdatename"
        Me.txtupdatename.Size = New System.Drawing.Size(143, 20)
        Me.txtupdatename.TabIndex = 10
        Me.txtupdatename.Text = "input new column name here"
        '
        'btnupdate
        '
        Me.btnupdate.Location = New System.Drawing.Point(171, 314)
        Me.btnupdate.Margin = New System.Windows.Forms.Padding(2)
        Me.btnupdate.Name = "btnupdate"
        Me.btnupdate.Size = New System.Drawing.Size(81, 28)
        Me.btnupdate.TabIndex = 11
        Me.btnupdate.Text = "update column"
        Me.btnupdate.UseVisualStyleBackColor = True
        '
        'Timer1
        '
        '
        'lblmessage
        '
        Me.lblmessage.AutoSize = True
        Me.lblmessage.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.142858!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblmessage.ForeColor = System.Drawing.Color.Crimson
        Me.lblmessage.Location = New System.Drawing.Point(53, 139)
        Me.lblmessage.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblmessage.Name = "lblmessage"
        Me.lblmessage.Size = New System.Drawing.Size(62, 13)
        Me.lblmessage.TabIndex = 13
        Me.lblmessage.Text = "placeholder"
        Me.lblmessage.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(211, 270)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 14
        Me.Button1.Text = "Button1"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'frm1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 485)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.lblmessage)
        Me.Controls.Add(Me.btnupdate)
        Me.Controls.Add(Me.txtupdatename)
        Me.Controls.Add(Me.cmbcolumns)
        Me.Controls.Add(Me.btnclear)
        Me.Controls.Add(Me.txtaddinput)
        Me.Controls.Add(Me.btnadd)
        Me.Controls.Add(Me.btnsave)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.btnopen)
        Me.Name = "frm1"
        Me.Text = "xml"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnopen As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents btnsave As Button
    Friend WithEvents btnadd As Button
    Friend WithEvents txtaddinput As TextBox
    Friend WithEvents btnclear As Button
    Friend WithEvents cmbcolumns As ComboBox
    Friend WithEvents txtupdatename As TextBox
    Friend WithEvents btnupdate As Button
    Friend WithEvents Timer1 As Timer
    Friend WithEvents lblmessage As Label
    Friend WithEvents Button1 As Button
End Class
